
# coding: utf-8

# In[ ]:


import ktrain

import tensorflow as tf
mirrored_strategy = tf.distribute.MirroredStrategy()
# In[ ]:


import os
os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID";
 
# The GPU id to use, usually either "0" or "1";
os.environ["CUDA_VISIBLE_DEVICES"]="1,2";  
os.environ["OMP_NUM_THREADS"] = "2"
 


# In[ ]:


from ktrain import text


# In[ ]:


from sklearn.utils import resample
import numpy as np
from numpy import array
#Masterdir = '/content/drive/My Drive/Research Project/'
#Datadir = 'Data/'
#Modeldir = 'Models/'
#Featuredir = 'Features/'
#inputdatasetfilename = 'tamil_train.tsv'
#exp_details = 'new_experiment'
#SEPERATOR = ','
#DATA_COLUMN = 0
#LABEL_COLUMN = 1
#LABELS = ['not-Tamil','unknown_state', 'Positive', 'Mixed_feelings', 'Negative']


# In[ ]:



f=open('malayalam_hope_full.csv','r')
lines = f.read()
lines = lines.split('\n')[:-1]


X = []
Y = []
data = []


for i in range(len(lines)):
 line = lines[i].split(',')
#     data.append(a)
 if len(line[0])>0:
   X.append(line[1])
   Y.append(line[0])
Y = np.asarray(Y)
X = np.asarray(X)


# In[ ]:


# import pandas as pd
# df = pd.DataFrame(data, columns = ['labels', 'Sentences']) 


# In[ ]:


from sklearn.model_selection import train_test_split
X_train, X_test, Y_train, Y_test = train_test_split( X, Y, test_size=0.1, random_state=5)


# In[ ]:


X_train, X_dev, Y_train, Y_dev = train_test_split( X_train, Y_train, test_size=0.111, random_state=5)


# In[ ]:


X_train_csv = []
for x in range(len(X_train)):
    line = []
    line.append(X_train[x])
    line.append(Y_train[x])
    X_train_csv.append(line)
    

out = open('malayalam_train.csv', 'w')
for row in X_train_csv:
    for column in row:
        out.write('%s;' % column)
    out.write('\n')
out.close()


# In[ ]:


X_test_csv = []
for x in range(len(X_test)):
    line = []
    line.append(X_test[x])
    line.append(Y_test[x])
    X_test_csv.append(line)
    

out = open('malayalam_test.csv', 'w')
for row in X_test_csv:
    for column in row:
        out.write('%s;' % column)
    out.write('\n')
out.close()


# In[ ]:


X_dev_csv = []
for x in range(len(X_dev)):
    line = []
    line.append(X_dev[x])
    line.append(Y_dev[x])
    X_dev_csv.append(line)
    

out = open('malayalam_dev.csv', 'w')
for row in X_dev_csv:
    for column in row:
        out.write('%s;' % column)
    out.write('\n')
out.close()


# In[ ]:


def DistilBert(X_train,Y_train,X_test,Y_test):
  MODEL_NAME = 'distilbert-base-uncased'
  t_distilbert = text.Transformer(MODEL_NAME, maxlen=500, classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
  trn_distilbert = t_distilbert.preprocess_train(X_train, Y_train)
  val_distilbert = t_distilbert.preprocess_test(X_test, Y_test)
  with mirrored_strategy.scope():
    model_distilbert = t_distilbert.get_classifier()
  learner_distilbert = ktrain.get_learner(model_distilbert, train_data=trn_distilbert, val_data=val_distilbert, batch_size=6)
  learner_distilbert.fit_onecycle(5e-3, 4)
  Predictor = ktrain.get_predictor(learner_distilbert.model, preproc=t_distilbert)
  return learner_distilbert, Predictor


# In[ ]:


def Bert(X_train,Y_train,X_test,Y_test):
 MODEL_NAME = 'bert-base-uncased'
 t_bert = text.Transformer(MODEL_NAME, maxlen=500,classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
 trn_bert = t_bert.preprocess_train(X_train, Y_train)
 val_bert = t_bert.preprocess_test(X_test, Y_test)
 with mirrored_strategy.scope():
  model_bert = t_bert.get_classifier()
 learner_bert = ktrain.get_learner(model_bert, train_data=trn_bert, val_data=val_bert, batch_size=6)
 learner_bert.fit_onecycle(5e-3, 4)
 Predictor = ktrain.get_predictor(learner_bert.model, preproc=t_bert)
 return learner_bert, Predictor


# In[ ]:


def XLNet(X_train,Y_train,X_test,Y_test):
 MODEL_NAME = 'xlnet-base-cased'
 t_xlnet = text.Transformer(MODEL_NAME, maxlen=500,classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
 trn_xlnet = t_xlnet.preprocess_train(X_train, Y_train)
 val_xlnet = t_xlnet.preprocess_test(X_test, Y_test)
 with mirrored_strategy.scope():
  model_xlnet = t_xlnet.get_classifier()
 learner_xlnet = ktrain.get_learner(model_xlnet, train_data=trn_xlnet, val_data=val_xlnet, batch_size=6)
 learner_xlnet.fit_onecycle(5e-3, 4)
 Predictor = ktrain.get_predictor(learner_xlnet.model, preproc=t_xlnet)
 return learner_xlnet, Predictor


# In[ ]:


def Roberta(X_train,Y_train,X_test,Y_test):
  MODEL_NAME = 'roberta-base'
  # model = None
  t_roberta = text.Transformer(MODEL_NAME, maxlen=500,classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
  trn_roberta = t_roberta.preprocess_train(X_train, Y_train)
  val_roberta = t_roberta.preprocess_test(X_test, Y_test)
  with mirrored_strategy.scope():
    model_roberta = t_roberta.get_classifier()
  learner_roberta = ktrain.get_learner(model_roberta, train_data=trn_roberta, val_data=val_roberta, batch_size=6)
  learner_roberta.fit_onecycle(5e-3, 4)
  # model = learner_roberta
  Predictor = ktrain.get_predictor(learner_roberta.model, preproc=t_roberta)
  return learner_roberta, Predictor


# In[ ]:


def Albert(X_train,Y_train,X_test,Y_test):
  MODEL_NAME = 'albert-base-v2'
  # model = None
  t_albert = text.Transformer(MODEL_NAME, maxlen=500,classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
  trn_albert = t_albert.preprocess_train(X_train, Y_train)
  val_albert = t_albert.preprocess_test(X_test, Y_test)
  with mirrored_strategy.scope():
    model_albert = t_albert.get_classifier()
  learner_albert = ktrain.get_learner(model_albert, train_data=trn_albert, val_data=val_albert, batch_size=6)
  learner_albert.fit_onecycle(5e-3, 4)
  # model = learner_roberta
  Predictor = ktrain.get_predictor(learner_albert.model, preproc=t_albert)
  return learner_albert, Predictor


# In[ ]:


def XLM(X_train,Y_train,X_test,Y_test):
  MODEL_NAME = 'xlm-mlm-100-1280'
  # model = None
  t_xlm = text.Transformer(MODEL_NAME, maxlen=500,classes=['Hope_speech','Non_hope_speech', 'not-malayalam'])
  trn_xlm = t_xlm.preprocess_train(X_train, Y_train)
  val_xlm = t_xlm.preprocess_test(X_test, Y_test)
  with mirrored_strategy.scope():
    model_xlm = t_xlm.get_classifier()
  learner_xlm = ktrain.get_learner(model_xlm, train_data=trn_xlm, val_data=val_xlm, batch_size=6)
  learner_xlm.fit_onecycle(5e-3, 4)
  # model = learner_roberta
  Predictor = ktrain.get_predictor(learner_xlm.model, preproc=t_xlm)
  return learner_xlm, Predictor


# In[ ]:


def model_predictions(predictor, X_test):
    return predictor.predict(X_test) 


from sklearn.metrics import classification_report
import pandas as pd







# In[ ]:


members, predictors = list(), list()
model_XLNet, Predictor_XLNet = XLNet(X,Y,X_dev,Y_dev)
members.append(model_XLNet)
predictors.append(Predictor_XLNet)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_XLNet, x)
    Y_pred.append(y)


# In[ ]:



report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('XLNet_Report.csv', sep=';')

###################################################


##################Distelbert####################try#############################

model_DistilBert, Predictor_DistilBert = DistilBert(X,Y,X_dev,Y_dev)
members.append(model_DistilBert)
predictors.append(Predictor_DistilBert)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_DistilBert, x)
    Y_pred.append(y)


# In[ ]:


report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('DistilBert_Report.csv', sep=';')

################################################################################


####################################################
# In[ ]:


model_Roberta, Predictor_Roberta = Roberta(X,Y,X_dev,Y_dev)
members.append(model_Roberta)
predictors.append(Predictor_Roberta)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_Roberta, x)
    Y_pred.append(y)


# In[ ]:


from sklearn.metrics import classification_report
report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('Roberta_Report.csv', sep=';')


# In[ ]:
############################################################################

model_Bert, Predictor_Bert = Bert(X,Y,X_dev,Y_dev)
members.append(model_Bert)
predictors.append(Predictor_Bert)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_Bert, x)
    Y_pred.append(y)


# In[ ]:


report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('Bert_Report.csv', sep=';')


# In[ ]:

#######################################################################

# In[ ]:


model_Albert, Predictor_Albert = Albert(X,Y,X_dev,Y_dev)
members.append(model_Albert)
predictors.append(Predictor_Albert)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_Albert, x)
    Y_pred.append(y)


# In[ ]:


report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('Albert_Report.csv', sep=';')

##################################################################################
# In[ ]:


model_XLM, Predictor_XLM = XLM(X,Y,X_dev,Y_dev)
members.append(model_XLM)
predictors.append(Predictor_XLM)


# In[ ]:


Y_pred = []
for x in X_test:
    y = model_predictions(Predictor_XLM, x)
    Y_pred.append(y)


# In[ ]:


report = classification_report(Y_test, Y_Pred, ['Hope_speech','Non_hope_speech', 'not-malayalam'], output_dict=True)
df = pandas.DataFrame(report).transpose()
df.to_csv('XLM_Report.csv', sep=';')

